# ClearLens AI (Android)

A native Kotlin Android starter app for locally enhancing hazy-looking photos and videos.

## Current features
- Select a photo from the Android document picker.
- Locally apply a restrained contrast, saturation and sharpening adjustment to the photo.
- Save enhanced photos into `Pictures/ClearLensAI`.
- Select a video, apply a Media3 contrast effect and export it as MP4.
- Save enhanced videos into `Movies/ClearLensAI`.
- GitHub Actions workflow builds a debug APK and uploads it as an artifact.

## Build an APK with GitHub
1. Upload the project files to the repository root.
2. Open the **Actions** tab and enable Actions if GitHub asks.
3. Run **Build ClearLens AI APK** or push a commit to `main`/`master`.
4. Open the finished workflow run and download the `ClearLensAI-debug-apk` artifact.

The build uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and AndroidX Media3 1.6.1.

## Important limitations
This is a lightweight on-device enhancement filter, not a trained AI restoration model. It may improve contrast and perceived clarity, but cannot reconstruct details that were not captured. It also cannot remove moisture trapped inside a physical camera lens. Processing large images/videos can require substantial memory and storage. Keep the app open during video export.

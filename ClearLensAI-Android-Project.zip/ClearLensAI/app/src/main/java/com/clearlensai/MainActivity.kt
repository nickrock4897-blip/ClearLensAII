package com.clearlensai

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.effect.Contrast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var status: TextView
    private lateinit var preview: ImageView
    private var selectedImage: Uri? = null
    private var selectedVideo: Uri? = null
    private var transformer: Transformer? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val pickImageCode = 101
    private val pickVideoCode = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(16, 20, 31)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(26))
            gravity = Gravity.CENTER_HORIZONTAL
        }
        scroll.addView(root)

        val brand = TextView(this).apply {
            text = "ClearLens AI"
            textSize = 30f
            setTextColor(Color.rgb(66, 215, 197))
            gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(brand, fullWidth())
        root.addView(TextView(this).apply {
            text = "Make hazy photos and videos clearer"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
        }, fullWidth())

        addButton(root, "Choose a photo") { pickMedia("image/*", pickImageCode) }
        addButton(root, "Enhance photo") { enhanceSelectedImage() }
        addButton(root, "Choose a video") { pickMedia("video/*", pickVideoCode) }
        addButton(root, "Enhance and export video") { enhanceSelectedVideo() }

        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(29, 35, 49))
            contentDescription = "Selected photo preview"
        }
        val previewParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(250))
        previewParams.topMargin = dp(10)
        previewParams.bottomMargin = dp(14)
        root.addView(preview, previewParams)

        status = TextView(this).apply {
            text = "Choose a photo or video to begin. Processing happens on this device."
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        root.addView(status, fullWidth())

        root.addView(TextView(this).apply {
            text = "Note: enhancement can improve contrast and visibility, but cannot recover details that were never captured or remove moisture inside a camera lens."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(dp(4), dp(16), dp(4), dp(8))
        }, fullWidth())
        setContentView(scroll)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = 15f
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(31, 112, 113))
            setOnClickListener { action() }
        }
        val params = fullWidth().apply { bottomMargin = dp(10) }
        parent.addView(button, params)
    }

    private fun pickMedia(type: String, code: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, code)
    }

    @Deprecated("Uses the stable Android document picker for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
        when (requestCode) {
            pickImageCode -> {
                selectedImage = uri
                selectedVideo = null
                try {
                    contentResolver.openInputStream(uri)?.use { preview.setImageBitmap(decodeSampled(it)) }
                    status.text = "Photo selected. Tap Enhance photo."
                } catch (e: Exception) { status.text = "Could not open this photo: ${e.localizedMessage}" }
            }
            pickVideoCode -> {
                selectedVideo = uri
                selectedImage = null
                preview.setImageDrawable(null)
                status.text = "Video selected. Tap Enhance and export video."
            }
        }
    }

    private fun decodeSampled(input: InputStream): Bitmap {
        val bytes = input.readBytes()
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: throw IOException("Unsupported image")
    }

    private fun enhanceSelectedImage() {
        val uri = selectedImage
        if (uri == null) { toast("Choose a photo first."); return }
        status.text = "Enhancing photo…"
        executor.execute {
            try {
                val source = contentResolver.openInputStream(uri)?.use { decodeSampled(it) }
                    ?: throw IOException("Could not read photo")
                val output = enhanceBitmap(source)
                val saved = saveBitmap(output)
                runOnUiThread {
                    preview.setImageBitmap(output)
                    status.text = if (saved != null) "Done! Enhanced photo saved to Pictures/ClearLensAI." else "Enhanced, but saving failed."
                    if (saved != null) toast("Photo saved")
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Could not enhance photo: ${e.localizedMessage ?: "unknown error"}" }
            }
        }
    }

    // A lightweight local dehaze-style adjustment: contrast, mild saturation and sharpening are intentionally restrained.
    private fun enhanceBitmap(input: Bitmap): Bitmap {
        val w = input.width
        val h = input.height
        val pixels = IntArray(w * h)
        input.getPixels(pixels, 0, w, 0, 0, w, h)
        val original = pixels.copyOf()
        val contrast = 1.18f
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                val c = original[i]
                val r = Color.red(c).toFloat()
                val g = Color.green(c).toFloat()
                val b = Color.blue(c).toFloat()
                val gray = (r * 0.299f + g * 0.587f + b * 0.114f)
                val sat = 1.07f
                var nr = ((gray + (r - gray) * sat - 127.5f) * contrast + 127.5f).coerceIn(0f, 255f)
                var ng = ((gray + (g - gray) * sat - 127.5f) * contrast + 127.5f).coerceIn(0f, 255f)
                var nb = ((gray + (b - gray) * sat - 127.5f) * contrast + 127.5f).coerceIn(0f, 255f)
                if (x in 1 until w - 1 && y in 1 until h - 1) {
                    val left = original[i - 1]; val right = original[i + 1]
                    val up = original[i - w]; val down = original[i + w]
                    nr = (nr + 0.12f * (Color.red(c) * 4 - Color.red(left) - Color.red(right) - Color.red(up) - Color.red(down))).coerceIn(0f,255f)
                    ng = (ng + 0.12f * (Color.green(c) * 4 - Color.green(left) - Color.green(right) - Color.green(up) - Color.green(down))).coerceIn(0f,255f)
                    nb = (nb + 0.12f * (Color.blue(c) * 4 - Color.blue(left) - Color.blue(right) - Color.blue(up) - Color.blue(down))).coerceIn(0f,255f)
                }
                pixels[i] = Color.argb(Color.alpha(c), nr.toInt(), ng.toInt(), nb.toInt())
            }
        }
        return Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun saveBitmap(bitmap: Bitmap): Uri? {
        val name = "ClearLens_${timestamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (android.os.Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearLensAI")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun enhanceSelectedVideo() {
        val uri = selectedVideo
        if (uri == null) { toast("Choose a video first."); return }
        val outputFile = File(cacheDir, "ClearLens_${timestamp()}.mp4")
        status.text = "Processing video… keep the app open until export finishes."
        try {
            val item = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                .setEffects(Effects(emptyList(), listOf(Contrast(0.16f))))
                .build()
            transformer = Transformer.Builder(this)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        executor.execute {
                            val saved = saveVideo(outputFile)
                            runOnUiThread {
                                status.text = if (saved != null) "Done! Enhanced video saved to Movies/ClearLensAI." else "Video processed, but saving to gallery failed."
                                if (saved != null) toast("Video saved")
                            }
                            outputFile.delete()
                        }
                    }
                    override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                        outputFile.delete()
                        runOnUiThread { status.text = "Video export failed: ${exportException.localizedMessage ?: "unsupported video format"}" }
                    }
                })
                .build()
            transformer?.start(item, outputFile.absolutePath)
        } catch (e: Exception) {
            outputFile.delete()
            status.text = "Could not start video processing: ${e.localizedMessage ?: "unknown error"}"
        }
    }

    private fun saveVideo(file: File): Uri? {
        if (!file.exists() || file.length() == 0L) return null
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "ClearLens_${timestamp()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (android.os.Build.VERSION.SDK_INT >= 29) put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearLensAI")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } }
            uri
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            null
        }
    }

    private fun timestamp(): String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun fullWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        transformer?.cancel()
        executor.shutdown()
        super.onDestroy()
    }
}

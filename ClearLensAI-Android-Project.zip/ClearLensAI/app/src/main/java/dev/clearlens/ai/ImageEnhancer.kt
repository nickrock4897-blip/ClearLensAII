package dev.clearlens.ai

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * A lightweight, offline image enhancer. It applies a conservative atmospheric-haze
 * correction plus mild local sharpening. It is a heuristic, not a trained AI model;
 * it cannot recreate detail physically hidden by droplets or severe optical blur.
 */
object ImageEnhancer {
    fun enhance(input: Bitmap): Bitmap {
        val src = if (input.config != Bitmap.Config.ARGB_8888) {
            input.copy(Bitmap.Config.ARGB_8888, false)
        } else input
        val width = src.width
        val height = src.height
        val count = width * height
        val pixels = IntArray(count)
        src.getPixels(pixels, 0, width, 0, 0, width, height)

        val histogram = IntArray(256)
        val luminances = IntArray(count)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p)
            val g = Color.green(p)
            val b = Color.blue(p)
            val y = ((77 * r + 150 * g + 29 * b) shr 8).coerceIn(0, 255)
            luminances[i] = y
            histogram[y]++
        }

        // Estimate the atmospheric light from the brightest ~1.5% of the image.
        val targetBright = max(1, (count * 0.985).roundToInt())
        var cumulative = 0
        var threshold = 220
        for (v in 0..255) {
            cumulative += histogram[v]
            if (cumulative >= targetBright) {
                threshold = v
                break
            }
        }
        var airR = 0L
        var airG = 0L
        var airB = 0L
        var airCount = 0
        for (i in pixels.indices) {
            if (luminances[i] >= threshold) {
                val p = pixels[i]
                airR += Color.red(p)
                airG += Color.green(p)
                airB += Color.blue(p)
                airCount++
            }
        }
        if (airCount == 0) airCount = 1
        val aR = max(155, (airR / airCount).toInt()).coerceAtMost(255)
        val aG = max(155, (airG / airCount).toInt()).coerceAtMost(255)
        val aB = max(155, (airB / airCount).toInt()).coerceAtMost(255)
        val omega = if (threshold >= 185) 0.72f else 0.48f

        val dehazed = IntArray(count)
        for (i in pixels.indices) {
            val p = pixels[i]
            val r = Color.red(p).toFloat()
            val g = Color.green(p).toFloat()
            val b = Color.blue(p).toFloat()
            val darkRatio = min(r / aR, min(g / aG, b / aB)).coerceIn(0f, 1f)
            val transmission = (1f - omega * darkRatio).coerceIn(0.56f, 0.98f)
            var nr = (aR + (r - aR) / transmission).coerceIn(0f, 255f)
            var ng = (aG + (g - aG) / transmission).coerceIn(0f, 255f)
            var nb = (aB + (b - aB) / transmission).coerceIn(0f, 255f)

            // Gentle contrast and saturation improvements avoid an overly harsh result.
            val gray = 0.299f * nr + 0.587f * ng + 0.114f * nb
            nr = (gray + (nr - gray) * 1.06f)
            ng = (gray + (ng - gray) * 1.06f)
            nb = (gray + (nb - gray) * 1.06f)
            nr = ((nr - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            ng = ((ng - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            nb = ((nb - 128f) * 1.06f + 128f).coerceIn(0f, 255f)
            dehazed[i] = Color.argb(Color.alpha(p), nr.roundToInt(), ng.roundToInt(), nb.roundToInt())
        }

        // Mild 4-neighbour unsharp mask; deliberately restrained to avoid strong halos.
        val sharpened = IntArray(count)
        for (y in 0 until height) {
            val upY = max(0, y - 1)
            val downY = min(height - 1, y + 1)
            for (x in 0 until width) {
                val leftX = max(0, x - 1)
                val rightX = min(width - 1, x + 1)
                val i = y * width + x
                val center = dehazed[i]
                val left = dehazed[y * width + leftX]
                val right = dehazed[y * width + rightX]
                val up = dehazed[upY * width + x]
                val down = dehazed[downY * width + x]
                val rAvg = (Color.red(left) + Color.red(right) + Color.red(up) + Color.red(down)) / 4f
                val gAvg = (Color.green(left) + Color.green(right) + Color.green(up) + Color.green(down)) / 4f
                val bAvg = (Color.blue(left) + Color.blue(right) + Color.blue(up) + Color.blue(down)) / 4f
                val r = (Color.red(center) + (Color.red(center) - rAvg) * 0.18f).coerceIn(0f, 255f)
                val g = (Color.green(center) + (Color.green(center) - gAvg) * 0.18f).coerceIn(0f, 255f)
                val b = (Color.blue(center) + (Color.blue(center) - bAvg) * 0.18f).coerceIn(0f, 255f)
                sharpened[i] = Color.argb(Color.alpha(center), r.roundToInt(), g.roundToInt(), b.roundToInt())
            }
        }

        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        result.setPixels(sharpened, 0, width, 0, 0, width, height)
        return result
    }

    fun blend(original: Bitmap, enhanced: Bitmap, strengthPercent: Int): Bitmap {
        if (strengthPercent <= 0) return original
        if (strengthPercent >= 100) return enhanced
        val width = min(original.width, enhanced.width)
        val height = min(original.height, enhanced.height)
        val originalPixels = IntArray(width * height)
        val enhancedPixels = IntArray(width * height)
        original.getPixels(originalPixels, 0, width, 0, 0, width, height)
        enhanced.getPixels(enhancedPixels, 0, width, 0, 0, width, height)
        val ratio = strengthPercent / 100f
        val inverse = 1f - ratio
        val resultPixels = IntArray(width * height)
        for (i in resultPixels.indices) {
            val a = originalPixels[i]
            val b = enhancedPixels[i]
            val r = (Color.red(a) * inverse + Color.red(b) * ratio).roundToInt()
            val g = (Color.green(a) * inverse + Color.green(b) * ratio).roundToInt()
            val blue = (Color.blue(a) * inverse + Color.blue(b) * ratio).roundToInt()
            resultPixels[i] = Color.argb(255, r, g, blue)
        }
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
            it.setPixels(resultPixels, 0, width, 0, 0, width, height)
        }
    }
}

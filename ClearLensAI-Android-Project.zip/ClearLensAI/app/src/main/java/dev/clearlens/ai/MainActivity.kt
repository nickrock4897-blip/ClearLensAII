package dev.clearlens.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.exifinterface.media.ExifInterface
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.max

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var previewView: PreviewView
    private lateinit var resultImage: ImageView
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var captureButton: MaterialButton
    private lateinit var galleryButton: MaterialButton
    private lateinit var flipButton: MaterialButton
    private lateinit var videoButton: MaterialButton
    private lateinit var recordVideoButton: MaterialButton
    private lateinit var resultControls: LinearLayout
    private lateinit var strengthLabel: TextView
    private lateinit var strengthSeekBar: SeekBar
    private lateinit var saveButton: MaterialButton
    private lateinit var previewCard: MaterialCardView

    private var imageCapture: ImageCapture? = null
    private var activeTransformer: Transformer? = null
    private var pendingVideoCaptureUri: Uri? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private var cameraStarting = false
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var originalBitmap: Bitmap? = null
    private var enhancedBitmap: Bitmap? = null
    private var renderGeneration = 0
    private var currentStrength = 100

    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera() else {
            statusText.text = "Kamerazugriff fehlt. Du kannst weiterhin ein Bild aus der Galerie öffnen."
        }
    }

    private val imagePicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) loadAndEnhance { decodeUri(uri) }
    }

    private val videoPicker = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) enhanceVideo(uri)
    }

    private val recordVideoLauncher = registerForActivityResult(
        ActivityResultContracts.CaptureVideo()
    ) { success ->
        val uri = pendingVideoCaptureUri
        pendingVideoCaptureUri = null
        if (uri == null) return@registerForActivityResult
        if (success) {
            val visible = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(uri, visible, null, null)
            enhanceVideo(uri)
        } else {
            contentResolver.delete(uri, null, null)
            statusText.text = "Videoaufnahme abgebrochen."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 16, 32)
        window.navigationBarColor = Color.rgb(10, 16, 32)
        buildUi()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    override fun onDestroy() {
        activeTransformer?.cancel()
        activeTransformer = null
        super.onDestroy()
        worker.shutdown()
    }

    private fun buildUi() {
        val background = Color.rgb(10, 16, 32)
        val surface = Color.rgb(18, 27, 46)
        val text = Color.rgb(245, 247, 255)
        val muted = Color.rgb(165, 174, 196)
        val accent = Color.rgb(139, 124, 255)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(background)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(26))
            setBackgroundColor(background)
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val topLine = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleColumn.addView(TextView(this).apply {
            this.text = "ClearLens AI"
            setTextColor(text)
            textSize = 28f
            setTypeface(typeface, Typeface.BOLD)
        })
        titleColumn.addView(TextView(this).apply {
            this.text = "FOTOS & VIDEOS KLARER"
            setTextColor(accent)
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.12f
        })
        topLine.addView(titleColumn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val offlineBadge = TextView(this).apply {
            this.text = "● OFFLINE"
            setTextColor(Color.rgb(159, 240, 199))
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            this.background = roundedDrawable(Color.rgb(22, 53, 51), dp(24))
        }
        topLine.addView(offlineBadge)
        root.addView(topLine)

        root.addView(TextView(this).apply {
            this.text = "Reduziert milchigen Schleier und verbessert Kontrast – direkt auf deinem Handy."
            setTextColor(muted)
            textSize = 14f
            setLineSpacing(dp(3).toFloat(), 1f)
        }, marginParams(top = 8, bottom = 16))

        previewCard = MaterialCardView(this).apply {
            radius = dp(26).toFloat()
            cardElevation = 0f
            setCardBackgroundColor(surface)
            strokeWidth = dp(1)
            strokeColor = Color.rgb(42, 54, 79)
            useCompatPadding = false
        }
        val frame = FrameLayout(this).apply { setBackgroundColor(surface) }
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
        resultImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(10, 13, 22))
            visibility = View.GONE
            contentDescription = "Vorschau des verbesserten Fotos"
        }
        frame.addView(previewView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        frame.addView(resultImage, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        previewCard.addView(frame, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(390)))
        root.addView(previewCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(390)))

        progressBar = ProgressBar(this).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(accent)
            visibility = View.GONE
        }
        root.addView(progressBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        statusText = TextView(this).apply {
            this.text = "Richte die Kamera auf dein Motiv oder öffne ein Foto."
            setTextColor(muted)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(4), dp(8), dp(8))
        }
        root.addView(statusText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        captureButton = createButton("Foto aufnehmen", accent, text).apply {
            setOnClickListener {
                if (originalBitmap != null) showCamera() else takePhoto()
            }
        }
        galleryButton = createButton("Galerie öffnen", Color.rgb(35, 47, 72), text).apply {
            setOnClickListener { imagePicker.launch("image/*") }
        }
        buttonRow.addView(captureButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(6) })
        buttonRow.addView(galleryButton, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(6) })
        root.addView(buttonRow, marginParams(bottom = 8))

        val videoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        videoButton = createButton("Video verbessern", Color.rgb(35, 47, 72), text).apply {
            setOnClickListener { videoPicker.launch("video/*") }
        }
        recordVideoButton = createButton("Video aufnehmen", Color.rgb(25, 35, 55), text).apply {
            setOnClickListener { startExternalVideoRecording() }
        }
        videoRow.addView(videoButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        videoRow.addView(recordVideoButton, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(6) })
        root.addView(videoRow, marginParams(bottom = 8))

        flipButton = createButton("Wechsel zur Frontkamera", Color.rgb(25, 35, 55), muted).apply {
            strokeColor = android.content.res.ColorStateList.valueOf(Color.rgb(47, 62, 91))
            strokeWidth = dp(1)
            setOnClickListener { switchCamera() }
        }
        root.addView(flipButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)).apply { bottomMargin = dp(14) })

        resultControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            this.background = roundedDrawable(surface, dp(22))
            visibility = View.GONE
        }
        resultControls.addView(TextView(this).apply {
            this.text = "ERGEBNIS ANPASSEN"
            setTextColor(accent)
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.1f
        })
        strengthLabel = TextView(this).apply {
            this.text = "Verbesserung: 100 %"
            setTextColor(text)
            textSize = 14f
        }
        resultControls.addView(strengthLabel, marginParams(top = 8, bottom = 2))
        strengthSeekBar = SeekBar(this).apply {
            max = 100
            progress = 100
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            thumbTintList = android.content.res.ColorStateList.valueOf(text)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(55, 67, 91))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) strengthLabel.text = "Verbesserung: $progress %"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    currentStrength = seekBar?.progress ?: 100
                    renderBlend(currentStrength)
                }
            })
        }
        resultControls.addView(strengthSeekBar)
        val saveRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        saveButton = createButton("Verbessertes Foto speichern", accent, text).apply {
            setOnClickListener { saveResult() }
        }
        saveRow.addView(saveButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)))
        resultControls.addView(saveRow, marginParams(top = 10))
        root.addView(resultControls, marginParams(bottom = 14))

        root.addView(TextView(this).apply {
            this.text = "Fotos und Videos werden offline bearbeitet. Der Video-Modus reduziert milchigen Schleier über Kontrast- und Helligkeitsfilter. Echte, durch Wasser verdeckte Details lassen sich nicht zuverlässig rekonstruieren."
            setTextColor(Color.rgb(130, 143, 169))
            textSize = 11.5f
            setLineSpacing(dp(2).toFloat(), 1f)
        }, marginParams(top = 4))

        setContentView(scroll)
    }

    private fun createButton(label: String, color: Int, textColor: Int): MaterialButton {
        return MaterialButton(this).apply {
            text = label
            textSize = 13f
            isAllCaps = false
            setTextColor(textColor)
            backgroundTintList = android.content.res.ColorStateList.valueOf(color)
            cornerRadius = dp(16)
            insetTop = 0
            insetBottom = 0
            setPadding(dp(8), dp(8), dp(8), dp(8))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
    }

    private fun startCamera() {
        if (cameraStarting) return
        cameraStarting = true
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                cameraProvider = provider
                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }
                val capture = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                    .build()
                val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, capture)
                imageCapture = capture
                statusText.text = "Bereit. Aufnahme oder Galerie wählen."
            } catch (error: Exception) {
                imageCapture = null
                statusText.text = "Kamera konnte nicht gestartet werden. Öffne ein Bild aus der Galerie."
            } finally {
                cameraStarting = false
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun takePhoto() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            cameraPermission.launch(Manifest.permission.CAMERA)
            return
        }
        val capture = imageCapture
        if (capture == null) {
            statusText.text = "Die Kamera startet noch. Bitte gleich erneut tippen."
            startCamera()
            return
        }
        val file = File(cacheDir, "clearlens_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        statusText.text = "Foto wird aufgenommen …"
        capture.takePicture(output, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                loadAndEnhance { decodeFile(file) }
            }
            override fun onError(exception: ImageCaptureException) {
                statusText.text = "Aufnahme fehlgeschlagen: ${exception.message ?: "Unbekannter Fehler"}"
            }
        })
    }

    private fun switchCamera() {
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
            CameraSelector.LENS_FACING_FRONT
        } else CameraSelector.LENS_FACING_BACK
        flipButton.text = if (lensFacing == CameraSelector.LENS_FACING_BACK) "Wechsel zur Frontkamera" else "Wechsel zur Rückkamera"
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else cameraPermission.launch(Manifest.permission.CAMERA)
    }

    private fun showCamera() {
        originalBitmap = null
        enhancedBitmap = null
        resultImage.setImageDrawable(null)
        resultImage.visibility = View.GONE
        previewView.visibility = View.VISIBLE
        resultControls.visibility = View.GONE
        captureButton.text = "Foto aufnehmen"
        currentStrength = 100
        statusText.text = "Richte die Kamera auf dein Motiv oder öffne ein Foto."
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
    }

    private fun loadAndEnhance(loader: () -> Bitmap?) {
        runOnUiThread {
            progressBar.visibility = View.VISIBLE
            statusText.text = "Bild wird lokal verbessert …"
            captureButton.isEnabled = false
            galleryButton.isEnabled = false
            saveButton.isEnabled = false
        }
        worker.execute {
            try {
                val decoded = loader()
                if (decoded == null) throw IllegalStateException("Das Bild konnte nicht gelesen werden.")
                val enhanced = ImageEnhancer.enhance(decoded)
                mainHandler.post {
                    originalBitmap = decoded
                    enhancedBitmap = enhanced
                    currentStrength = 100
                    strengthSeekBar.progress = 100
                    strengthLabel.text = "Verbesserung: 100 %"
                    resultImage.setImageBitmap(enhanced)
                    previewView.visibility = View.GONE
                    resultImage.visibility = View.VISIBLE
                    resultControls.visibility = View.VISIBLE
                    captureButton.text = "Zur Kamera"
                    statusText.text = "Fertig. Passe die Stärke an oder speichere das Ergebnis."
                    progressBar.visibility = View.GONE
                    captureButton.isEnabled = true
                    galleryButton.isEnabled = true
                    saveButton.isEnabled = true
                }
            } catch (error: Exception) {
                mainHandler.post {
                    progressBar.visibility = View.GONE
                    captureButton.isEnabled = true
                    galleryButton.isEnabled = true
                    saveButton.isEnabled = true
                    statusText.text = "Konnte Bild nicht bearbeiten: ${error.message ?: "Unbekannter Fehler"}"
                }
            }
        }
    }

    private fun renderBlend(strength: Int) {
        val source = originalBitmap ?: return
        val enhanced = enhancedBitmap ?: return
        progressBar.visibility = View.VISIBLE
        worker.execute {
            val version = ++renderGeneration
            val result = ImageEnhancer.blend(source, enhanced, strength)
            mainHandler.post {
                if (version == renderGeneration) {
                    resultImage.setImageBitmap(result)
                    progressBar.visibility = View.GONE
                }
            }
        }
    }

    private fun saveResult() {
        val source = originalBitmap ?: return
        val enhanced = enhancedBitmap ?: return
        saveButton.isEnabled = false
        statusText.text = "Speichere in Bilder/ClearLensAI …"
        worker.execute {
            try {
                val exportBitmap = ImageEnhancer.blend(source, enhanced, currentStrength)
                val name = "ClearLens_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ClearLensAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Speicherort konnte nicht erstellt werden.")
                try {
                    contentResolver.openOutputStream(uri)?.use { stream ->
                        if (!exportBitmap.compress(Bitmap.CompressFormat.JPEG, 94, stream)) {
                            throw IllegalStateException("JPEG konnte nicht geschrieben werden.")
                        }
                    } ?: throw IllegalStateException("Datei konnte nicht geöffnet werden.")
                    val done = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
                    contentResolver.update(uri, done, null, null)
                    mainHandler.post {
                        saveButton.isEnabled = true
                        statusText.text = "Gespeichert: Bilder/ClearLensAI/$name"
                        Toast.makeText(this, "Foto gespeichert", Toast.LENGTH_SHORT).show()
                    }
                } catch (error: Exception) {
                    contentResolver.delete(uri, null, null)
                    throw error
                }
            } catch (error: Exception) {
                mainHandler.post {
                    saveButton.isEnabled = true
                    statusText.text = "Speichern fehlgeschlagen: ${error.message ?: "Unbekannter Fehler"}"
                }
            }
        }
    }

    private fun startExternalVideoRecording() {
        try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "ClearLens_Original_$stamp.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearLensAI/Originals")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Speicherort für Video konnte nicht erstellt werden.")
            pendingVideoCaptureUri = uri
            statusText.text = "Videoaufnahme wird geöffnet …"
            recordVideoLauncher.launch(uri)
        } catch (error: Exception) {
            pendingVideoCaptureUri?.let { contentResolver.delete(it, null, null) }
            pendingVideoCaptureUri = null
            statusText.text = "Videoaufnahme konnte nicht gestartet werden: ${error.message ?: "Unbekannter Fehler"}"
        }
    }

    private fun enhanceVideo(sourceUri: Uri) {
        if (activeTransformer != null) {
            Toast.makeText(this, "Ein Video wird bereits bearbeitet.", Toast.LENGTH_SHORT).show()
            return
        }
        setVideoBusy(true, "Video wird verbessert. Je nach Länge kann das einige Minuten dauern …")
        val outputFile = File(cacheDir, "ClearLensVideo_${System.currentTimeMillis()}.mp4")
        outputFile.delete()
        try {
            val input = MediaItem.fromUri(sourceUri)
            // Lightweight local grading: lift contrast and slightly lower brightness to tame a milky veil.
            // This is not AI dehazing and cannot reconstruct details hidden by real water droplets.
            val edited = EditedMediaItem.Builder(input)
                .setEffects(Effects(emptyList(), listOf(Contrast(0.24f), Brightness(-0.025f))))
                .build()
            val transformer = Transformer.Builder(applicationContext)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        activeTransformer = null
                        worker.execute { copyEnhancedVideoToMediaStore(outputFile) }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        activeTransformer = null
                        outputFile.delete()
                        mainHandler.post {
                            setVideoBusy(false, "Video konnte nicht verarbeitet werden: ${exportException.message ?: "Format nicht unterstützt"}")
                        }
                    }
                })
                .build()
            activeTransformer = transformer
            transformer.start(edited, outputFile.absolutePath)
        } catch (error: Exception) {
            activeTransformer = null
            outputFile.delete()
            setVideoBusy(false, "Video konnte nicht gestartet werden: ${error.message ?: "Unbekannter Fehler"}")
        }
    }

    private fun copyEnhancedVideoToMediaStore(outputFile: File) {
        var destination: Uri? = null
        try {
            if (!outputFile.exists() || outputFile.length() <= 0L) {
                throw IllegalStateException("Die Ausgabedatei ist leer.")
            }
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "ClearLens_Enhanced_$stamp.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClearLensAI")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            destination = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Speicherort für das verbesserte Video konnte nicht erstellt werden.")
            contentResolver.openOutputStream(destination!!, "w")?.use { output ->
                outputFile.inputStream().use { input -> input.copyTo(output) }
            } ?: throw IllegalStateException("Die Videodatei konnte nicht gespeichert werden.")
            val visible = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            contentResolver.update(destination!!, visible, null, null)
            outputFile.delete()
            mainHandler.post {
                setVideoBusy(false, "Fertig! Gespeichert unter Filme/ClearLensAI.")
                Toast.makeText(this, "Verbessertes Video gespeichert", Toast.LENGTH_LONG).show()
            }
        } catch (error: Exception) {
            destination?.let { contentResolver.delete(it, null, null) }
            outputFile.delete()
            mainHandler.post {
                setVideoBusy(false, "Speichern fehlgeschlagen: ${error.message ?: "Unbekannter Fehler"}")
            }
        }
    }

    private fun setVideoBusy(busy: Boolean, message: String) {
        runOnUiThread {
            progressBar.visibility = if (busy) View.VISIBLE else View.GONE
            statusText.text = message
            captureButton.isEnabled = !busy
            galleryButton.isEnabled = !busy
            videoButton.isEnabled = !busy
            recordVideoButton.isEnabled = !busy
            flipButton.isEnabled = !busy
            if (::saveButton.isInitialized) saveButton.isEnabled = !busy
        }
    }

    private fun decodeUri(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
        val orientation = try {
            contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            } ?: ExifInterface.ORIENTATION_NORMAL
        } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
        return applyExifRotation(bitmap, orientation)
    }

    private fun decodeFile(file: File): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val options = BitmapFactory.Options().apply {
            inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight)
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val bitmap = BitmapFactory.decodeFile(file.absolutePath, options) ?: return null
        val orientation = try {
            ExifInterface(file).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
        return applyExifRotation(bitmap, orientation)
    }

    private fun sampleSize(width: Int, height: Int): Int {
        var sample = 1
        while (max(width / sample, height / sample) > 2000) sample *= 2
        return sample
    }

    private fun applyExifRotation(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.preScale(-1f, 1f); matrix.postRotate(90f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.preScale(-1f, 1f); matrix.postRotate(270f) }
        }
        if (matrix.isIdentity) return bitmap
        return try {
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (_: Exception) { bitmap }
    }

    private fun marginParams(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            if (top != 0) topMargin = dp(top)
            if (bottom != 0) bottomMargin = dp(bottom)
        }

    private fun roundedDrawable(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

# ClearLens AI currently disables minification for straightforward debugging.
